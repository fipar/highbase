
/* VERSION (from configure.in) */
#undef VERSION

